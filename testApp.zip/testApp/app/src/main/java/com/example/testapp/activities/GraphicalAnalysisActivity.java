package com.example.testapp.activities;

public class GraphicalAnalysisActivity {
}
